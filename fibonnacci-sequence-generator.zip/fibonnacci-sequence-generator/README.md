# Fibonacci Sequence Generator

This Python script generates the Fibonacci sequence up to the `n`th index using recursion. It returns the sequence as a list and demonstrates how recursive logic can be used to build up a mathematical pattern.

---

## Interpretation

The goal is to write a recursive function that returns a list of Fibonacci numbers up to a given index `n`. The Fibonacci sequence starts with `[1, 1]`, and each subsequent number is the sum of the previous two.

---

## Analysis

- The function `fibonacci_list(n)` uses recursion to build the sequence.
- The base cases are:
  - `n == 0`: returns `[1]`
  - `n == 1`: returns `[1, 1]`
- For `n > 1`, the function:
  - Recursively calls itself with `n-1`
  - Appends the sum of the last two elements in the list
  - Returns the updated list

This approach builds the sequence from the ground up, using the natural recursive structure of the Fibonacci definition.

---

## Algorithm Steps

1. Define a function `fibonacci_list(n)` that takes an integer `n`.
2. If `n == 0`, return `[1]`.
3. If `n == 1`, return `[1, 1]`.
4. Otherwise:
   - Recursively call `fibonacci_list(n-1)`
   - Append the sum of the last two elements to the list
   - Return the updated list

5. Call the function with desired values:
   ```python
   print(fibonacci_list(7))
   print(fibonacci_list(10))

## Example Output

[1, 1, 2, 3, 5, 8, 13, 21]
[1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

## How to Run

### Option 1: Terminal or Command Prompt

```bash
cd fibonacci-sequence
python fibonacci_list.py
```

### Option 2: VS Code

- Open the folder in VS Code
- Right-click fibonacci_list.py
- Select "Run Python File in Terminal"

## Concepts Demonstrated

- Recursion
- List manipulation
- Base cases and recursive growth
- Mathematical pattern generation
