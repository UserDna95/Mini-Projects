# GCD Calculator Using Recursion

This Python script calculates the **Greatest Common Divisor (GCD)** of two integers using the **Euclidean algorithm** implemented recursively. It also tracks and prints the recursion depth for educational insight.

---

## Interpretation

The goal is to write a recursive function that takes two integers and returns their GCD. The Euclidean algorithm works by repeatedly replacing the larger number with the remainder of dividing the two numbers, until the remainder is zero.

---

## Analysis

- The function accepts three parameters:
  - `n`: first integer
  - `m`: second integer
  - `depth`: tracks recursion depth (default is 0)
- The `abs()` function ensures both inputs are positive, as the Euclidean algorithm only works with non-negative values.
- The base case is when `m == 0`, in which case the GCD is `n`.
- Each recursive call prints the current depth and the values being processed.

---

## Algorithm Steps

1. Define a function `gcd(n: int, m: int, depth: int = 0)`
2. Convert `n` and `m` to their absolute values.
3. Print the current recursion depth and values.
4. If `m == 0`, return `n` as the GCD.
5. Otherwise, recursively call `gcd(m, n % m, depth + 1)`
6. Use a `try-except` block to validate user input and handle non-integer values.

---

## How to Run

### Option 1: Terminal or Command Prompt

```bash
cd gcd
python gcd_calculator.py
```

### Option 2: VS Code

- Open the folder in VS Code
- Right-click gcd_calculator.py
- Select "Run Python File in Terminal"

## Example Output
Enter the first integer: 48
Enter the second integer: 18
Recursion depth 0: gcd(48, 18)
Recursion depth 1: gcd(18, 12)
Recursion depth 2: gcd(12, 6)
Recursion depth 3: gcd(6, 0)

The GCD of 48 and 18 is 6

## Concepts Demonstrated
- Recursion
- Euclidean algorithm
- Input validation
- Type annotations
- Mutable default arguments (used safely for tracking depth)
