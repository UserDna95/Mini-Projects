def gcd(n: int, m: int, depth: int = 0):  #define a function called gcd which will take the values of n, m, and depth. But include that n and m can only be integers, whereas depth is also an integer but begins with a set value of 0. 
    n, m = abs(n), abs(m) #abs() ensures that any value for n and m is a positive one and so it remove the negative sign from a number as Euclidean logic only works with positive numbers.
    print(f"Recursion depth {depth}: gcd({n}, {m})") #This sets a print statement prior to employing the Euclidean logic where it prints out the depth or loops it had to go through to find the gcd between the two values.
    if m == 0: #if m is equal to 0 exactly
        return n #then return the value of n. This is the final case of the recursion which stops its from conitinuing. It says if m is 0, then the GCD is n.
    else:
        return gcd(m, n % m, depth + 1) #recursive function of gcd, where the first argument is m, and the second is n % m with no remainders, and depth adds one each time a gcd is found. 
try: #use try-except for data validation 
    num1 = int(input("Enter the first integer: ")) #get inputted value for n as num1
    num2 = int(input("Enter the second integer: ")) #get inputted value for m as num2
    result = gcd(num1, num2) #the result will use the gcd function on num1 and num2
    print(f"\nThe GCD of {num1} and {num2} is {result}") #for decorative purposes display num1 and num2 and the result of using the gcd function on them
except ValueError: #use ValueError to handle any other non-integer values which ends the program until rerun with integer values only
    print("Please enter valid intergers only.")