# News Article Analyzer 

This Python script analyzes a news article stored in a `.txt` file. It calculates word frequency, filters out common filler words, and identifies the top keywords that represent the essence of the article.

---

## Interpretation

The goal is to write a function that reads a text file, cleans it of punctuation and filler words, and then analyzes the frequency of meaningful words. The top 5 most frequent words are considered the "essence keywords" of the article.

---

## Analysis

- The function `news_analysis(article="newsarticle.txt")`:
  - Reads the file line by line
  - Removes punctuation and converts text to lowercase
  - Filters out common filler words (e.g., "the", "and", "is")
  - Tracks word frequency using a dictionary
  - Sorts and displays the top 20 most frequent words in a table

- Uses the `tabulate` module to format output in a readable grid.

---

## Algorithm Steps

1. Define a function `news_analysis(article="newsarticle.txt")`
2. Create a list of punctuation symbols to remove
3. Create a set of common filler words to exclude
4. Initialize a dictionary `w_dict` to store word frequencies
5. Read the file line by line:
   - Replace punctuation with spaces
   - Convert to lowercase and split into words
   - Skip filler words and empty strings
   - Count meaningful words and update frequency
6. Sort the dictionary by frequency (descending)
7. Extract the top 5 keywords as "essence"
8. Display:
   - Total meaningful word count
   - Number of unique words
   - Top 5 keywords
   - Top 20 words in a formatted table

---

Example Output

Total words (excluding filler): 722
Number of unique words: 410
Essence Keywords: ['air', 'that', 'with', 'more', 'as']

+--------------+-------------+
| Word         |   Frequency |
+==============+=============+
| air          |          16 |
+--------------+-------------+
| that         |          15 |
+--------------+-------------+
| with         |          14 |
+--------------+-------------+
| more         |           9 |
+--------------+-------------+
| as           |           9 |
+--------------+-------------+
| it's         |           8 |
+--------------+-------------+
| energy       |           8 |
+--------------+-------------+
| hot          |           7 |
+--------------+-------------+
| cool         |           7 |
+--------------+-------------+
| but          |           7 |
+--------------+-------------+
| cooling      |           7 |
+--------------+-------------+
| per          |           7 |
+--------------+-------------+
| some         |           6 |
+--------------+-------------+
| cent         |           6 |
+--------------+-------------+
| it           |           6 |
+--------------+-------------+
| have         |           6 |
+--------------+-------------+
| conditioning |           5 |
+--------------+-------------+
| about        |           5 |
+--------------+-------------+
| conditioners |           5 |
+--------------+-------------+
| we           |           5 |
+--------------+-------------+

(722,
 [('air', 16),
  ('that', 15),
  ('with', 14),
  ('more', 9),
  ('as', 9),
  ("it's", 8),
  ('energy', 8),
  ('hot', 7),
  ('cool', 7),
  ('but', 7),
  ('cooling', 7),
  ('per', 7),
  ('some', 6),
  ('cent', 6),
  ('it', 6),
  ('have', 6),
  ('conditioning', 5),
  ('about', 5),
  ('conditioners', 5),
  ('we', 5),
  ('for', 5),
  ('at', 5),
  ('which', 5),
  ('after', 4),
  ('climate', 4),
  ('heat', 4),
  ('people', 4),
  ('india', 4),
  ('iea', 4),
  ('countries', 4),
  ('own', 4),
  ('units', 4),
  ('one', 4),
  ('keeping', 4),
  ('buildings', 4),
  ('this', 4),
  ('because', 4),
  ('dulac', 4),
  ('mcnamara', 4),
  ('says', 4),
  ('ice', 4),
  ('home', 3),
  ('by', 3),
  ('most', 3),
  ('co2', 3),
  ('change', 3),
  ('â€”', 3),
  ('parts', 3),
  ('canada', 3),
  ('temperatures', 3),
  ('c', 3),
  ('country', 3),
  ("there's", 3),
  ('provide', 3),
  ('you', 3),
  ('than', 3),
  ('much', 3),
  ('something', 3),
  ('has', 3),
  ('important', 3),
  ('use', 3),
  ('they', 3),
  ('building', 3),
  ('walls', 3),
  ('said', 3),
  ('ensure', 3),
  ('not', 3),
  ('walking', 2),
  ('outside', 2),
  ('humid', 2),
  ('summer', 2),
  ('day', 2),
  ('like', 2),
  ('relief', 2),
  ('into', 2),
  ('your', 2),
  ('being', 2),
  ('emissions', 2),
  ('very', 2),
  ('thing', 2),
  ('occur', 2),
  ('world', 2),
  ('europe', 2),
  ('waves', 2),
  ('june', 2),
  ('died', 2),
  ('japan', 2),
  ('2', 2),
  ('need', 2),
  ('how', 2),
  ('do', 2),
  ('all', 2),
  ('say', 2),
  ('number', 2),
  ('90', 2),
  ('right', 2),
  ('could', 2),
  ('our', 2),
  ("'", 2),
  ('if', 2),
  ('look', 2),
  ('design', 2),
  ('today', 2),
  ('would', 2),
  ('then', 2),
  ('changed', 2),
  ('technology', 2),
  ('efficiency', 2),
  ('acs', 2),
  ('or', 2),
  ('less', 2),
  ('been', 2),
  ('health', 2),
  ('safety', 2),
  ('access', 2),
  ('issue', 2),
  ('developed', 2),
  ('fight', 2),
  ('solutions', 2),
  ('company', 2),
  ('uses', 2),
  ('during', 2),
  ('growing', 2),
  ('sun', 1),
  ('beating', 1),
  ('down', 1),
  ('there', 1),
  ('nothing', 1),
  ('sweet', 1),
  ('greeted', 1),
  ('dry', 1),
  ('relies', 1),
  ('electrical', 1),
  ('grid', 1),
  ('likely', 1),
  ('produces', 1),
  ('carbon', 1),
  ('dioxide', 1),
  ('contributing', 1),
  ('will', 1),
  ('cause', 1),
  ('days', 1),
  ('frequently', 1),
  ('intensity', 1),
  ('rising', 1),
  ('many', 1),
  ('globe', 1),
  ('across', 1),
  ('records', 1),
  ('were', 1),
  ('broken', 1),
  ('two', 1),
  ('descended', 1),
  ('region', 1),
  ('july', 1),
  ('dozens', 1),
  ('reached', 1),
  ('50', 1),
  ('11', 1),
  ('aug', 1),
  ('wave', 1),
  ('gripped', 1),
  ('reaching', 1),
  ('37', 1),
  ('earlier', 1),
  ('week', 1),
  ("that's", 1),
  ('problem', 1),
  ('regions', 1),
  ('predicted', 1),
  ('get', 1),
  ('hotter', 1),
  ('changing', 1),
  ('without', 1),
  ('going', 1),
  ('vicious', 1),
  ('circle', 1),
  ('further', 1),
  ('pumping', 1),
  ('efficiencies', 1),
  ('experts', 1),
  ("'cold", 1),
  ("crunch'", 1),
  ('according', 1),
  ('international', 1),
  ('agency', 1),
  ('approximately', 1),
  ('8', 1),
  ('billion', 1),
  ('live', 1),
  ('where', 1),
  ('average', 1),
  ('temperature', 1),
  ('25', 1),
  ('fewer', 1),
  ('10', 1),
  ('60', 1),
  ('households', 1),
  ('form', 1),
  ('united', 1),
  ('states', 1),
  ('rises', 1),
  ('now', 1),
  ('only', 1),
  ('five', 1),
  ('relatively', 1),
  ('cheap', 1),
  ('experiencing', 1),
  ('expected', 1),
  ('rapidly', 1),
  ('climb', 1),
  ('estimates', 1),
  ('2050', 1),
  ('75', 1),
  ("world's", 1),
  ('population', 1),
  ('conditioner', 1),
  ('organization', 1),
  ('refers', 1),
  ('cold', 1),
  ('crunch', 1),
  ('seen', 1),
  ('triple', 1),
  ('digit', 1),
  ('growth', 1),
  ('part', 1),
  ("isn't", 1),
  ('necessarily', 1),
  ('increasing', 1),
  ('make', 1),
  ('efficient', 1),
  ('possible', 1),
  ('stands', 1),
  ('extremely', 1),
  ('inefficient', 1),
  ('tend', 1),
  ('sector', 1),
  ("'build", 1),
  ('tight', 1),
  ('build', 1),
  ('reason', 1),
  ('back', 1),
  ('places', 1),
  ('used', 1),
  ('rammed', 1),
  ('earth', 1),
  ('thick', 1),
  ('overhangs', 1),
  ('porticos', 1),
  ('et', 1),
  ('cetera', 1),
  ('john', 1),
  ('consultant', 1),
  ('same', 1),
  ('italy', 1),
  ('greece', 1),
  ('historically', 1),
  ('white', 1),
  ('roofs', 1),
  ('coloured', 1),
  ('rejected', 1),
  ('essentially', 1),
  ('thin', 1),
  ('poor', 1),
  ('insulation', 1),
  ('lot', 1),
  ('gaps', 1),
  ('hard', 1),
  ('keep', 1),
  ('lack', 1),
  ('codes', 1),
  ('be', 1),
  ('priority', 1),
  ('no', 1),
  ('1', 1),
  ('order', 1),
  ('themselves', 1),
  ('study', 1),
  ('done', 1),
  ('collaboration', 1),
  ("canada's", 1),
  ('national', 1),
  ('board', 1),
  ('along', 1),
  ('second', 1),
  ('looked', 1),
  ('china', 1),
  ('research', 1),
  ('suggests', 1),
  ('barely', 1),
  ('almost', 1),
  ('century', 1),
  ('despite', 1),
  ('gains', 1),
  ('se', 1),
  ('evolved', 1),
  ('still', 1),
  ('started', 1),
  ('using', 1),
  ('1950s', 1),
  ('terms', 1),
  ('basic', 1),
  ('fact', 1),
  ('anticipated', 1),
  ('loads', 1),
  ('may', 1),
  ('rarely', 1),
  ('often', 1),
  ('oversized', 1),
  ('things', 1),
  ("we've", 1),
  ('discussing', 1),
  ('technical', 1),
  ('partners', 1),
  ('nrcan', 1),
  ('natural', 1),
  ('resources', 1),
  ('others', 1),
  ('around', 1),
  ("'do", 1),
  ('rethink', 1),
  ('actually', 1),
  ('big', 1),
  ('implications', 1),
  ('ensuring', 1),
  ('just', 1),
  ('feeling', 1),
  ('comfortable', 1),
  ('julie', 1),
  ('senior', 1),
  ('analyst', 1),
  ('union', 1),
  ('concerned', 1),
  ('scientists', 1),
  ('high', 1),
  ('contributors', 1),
  ('should', 1),
  ('equipment', 1),
  ('their', 1),
  ('lives', 1),
  ('depend', 1),
  ('such', 1),
  ('equity', 1),
  ('greater', 1),
  ('burden', 1),
  ('shoulder', 1),
  ('able', 1),
  ('eliminating', 1),
  ('food', 1),
  ('waste', 1),
  ('can', 1),
  ('help', 1),
  ('against', 1),
  ('5', 1),
  ('ideas', 1),
  ('through', 1),
  ('better', 1),
  ('land', 1),
  ('while', 1),
  ('governments', 1),
  ('trying', 1),
  ('green', 1),
  ('private', 1),
  ('companies', 1),
  ('working', 1),
  ('innovative', 1),
  ('california', 1),
  ('example', 1),
  ('called', 1),
  ('worked', 1),
  ('u', 1),
  ('s', 1),
  ('department', 1),
  ('bear', 1),
  ('simply', 1),
  ('put', 1),
  ('unit', 1),
  ('works', 1),
  ('together', 1),
  ('regular', 1),
  ('makes', 1),
  ('off', 1),
  ('peak', 1),
  ('hours', 1),
  ('typically', 1),
  ('demanding', 1),
  ('time', 1),
  ('needs', 1),
  ('becoming', 1),
  ('topic', 1),
  ('believe', 1),
  ('positive', 1),
  ('step', 1),
  ('move', 1),
  ('forward', 1),
  ('recognize', 1),
  ('threat', 1),
  ('begin', 1),
  ('wrestle', 1),
  ('i', 1),
  ('think', 1),
  ("we're", 1),
  ('starting', 1),
  ('see', 1),
  ('awareness', 1),
  ('certainly', 1),
  ('real', 1),
  ('challenge', 1),
  ('demands', 1),
  ('attention', 1)],
 ['air', 'that', 'with', 'more', 'as'])

## How to Run

### Option 1: Terminal or Command Prompt

```bash
cd read-txt
python news_analysis.py
```

### Option 2: VS code
- Open the folder in VS Code
- Right-click news_analysis.py
- Select "Run Python File in Terminal"

## Concepts Demonstrated
- File I/O
- String manipulation
- Dictionary usage
- Sorting with lambda functions
- Data filtering
- Tabular output formatting
