Welcome to the Taxes Calculator mini project! This folder contains two Python scripts that calculate income tax based on Canadian federal and provincial tax brackets. Each script demonstrates a different programming approach to solving the same problem

keyword_argument_tax_calculator : Calculates either federal or provincial tax using a keyword argument (level='f' or 'p' which represent provincial or federal)

Why use this style?
- Gives the user control over which tax to calculate.
- Keeps the function focused on a single responsibility.
- Great for scenarios where you want to isolate one tax type.
- Uses conditional logic

provincial_federal_tax_calculator : Calculates both federal and provincial tax amounts and returns them as a tuple.

Why use this style?
- More comprehensive—you get both tax values in one go.
- Ideal for full tax summaries or comparisons.
- Encourages modular design with reusable logic
- Uses nested function and tuples

How to use:
1) Launch in terminal or command prompt (windows : windows key + r and type in cmd). If using git, clone the repo, navigate to .py files and launch either folder assuming python is already downloaded in your computer.
2) If using VS code, download files or once again clone the repo using git, right-click .py files and run in the terminal. 