# Keyword Argument Tax Calculator

This Python script calculates either federal or provincial tax based on a given income using a keyword argument.

## Description

The function `calculate_total_tax(income, level='f')` takes two arguments:
- `income`: a numeric value representing the user's income
- `level`: a keyword argument that specifies the tax level (`'f'` for federal, `'p'` for provincial)

The function uses predefined tax brackets and applies the appropriate rates based on the selected level.

## How It Works

1. Validates that the income is a positive number.
2. Selects the correct tax bracket based on the `level` argument.
3. Iterates through the brackets, calculating tax for each applicable range.
4. Returns the total tax rounded to two decimal places.

## Usage

```bash
python keyword_argument_tax_calculator.py
```
## Example output 
Federal tax on $55,000: $8250.0
Provincial tax on $55,000: $1357.0

## Note
- Default level is 'f' (federal).
- If 'p' is passed, provincial tax is calculated.
- Invalid income inputs return None.

## Concepts Demonstrated
- Keyword arguments
- Conditional logic
- Tax bracket iteration
- Input validation

