# Provincial and Federal Tax Calculator

This Python script calculates both federal and provincial tax amounts on a given income using a single function call.

## Description

The function `calculate_total_tax(income)` returns a tuple containing:
- `federal_tax`: total federal tax payable
- `provincial_tax`: total provincial tax payable

It uses nested functions and bracket logic to compute each tax separately.

## How It Works

1. Validates that the income is a positive number.
2. Defines federal and provincial tax brackets.
3. Uses a helper function `calculate_tax()` to compute tax based on bracket ranges.
4. Returns both tax amounts as a tuple.

## Usage

```bash
python provincial_federal_tax_calculator.py
```

## Example output 
What is your income: 55000
Your total federal tax payable is $8250.0
Your total provincial tax payable is $1357.0

## Note
- Uses input prompts for user interaction.
- Returns both tax values in one function call.
- Invalid income inputs return None

## Concepts Demonstrated
- Function nesting
- Tuple return values
- Bracket-based tax calculation
- Input validation

