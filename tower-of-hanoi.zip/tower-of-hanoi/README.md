# Tower of Hanoi Solver 
This Python script solves the classic **Tower of Hanoi** puzzle using recursion. It prints each step required to move a stack of disks from one rod to another, following the puzzle's rules.

## Problem Description

The Tower of Hanoi is a mathematical puzzle where you have:
- Three rods: Source, Auxiliary, and Destination
- A number of disks of different sizes stacked on the Source rod

**Goal**: Move all disks to the Destination rod following these rules:
1. Only one disk can be moved at a time.
2. A larger disk cannot be placed on top of a smaller disk.
3. Only the top disk of any rod can be moved.


## How It Works

The function `tower_of_hanoi(n, source, auxiliary, destination, step)`:
- Uses recursion to break the problem into smaller subproblems.
- Tracks and prints each move with a step counter.
- Default rod labels are `'A'`, `'B'`, and `'C'`.

## How to Run?

### Option 1: Terminal or Command Prompt

```bash
cd tower-of-hanoi
python tower_of_hanoi.py
```

### Option 2: VS Code
Open the folder in VS Code
- Right-click 
- Select "Run Python File in Terminal"

### Example Output (for 3 disks)
1: A C
2: A B
3: C B
4: A C
5: B A
6: B C
7: A C

## Concepts used
- Recursion
- Default arguments
- Mutable state tracking with lists
- Algorithmic problem solving


## Customize
You can change the number of disks by modifying the number to see what the most optimized steps are when moving disks between rods as the number increases or decreases