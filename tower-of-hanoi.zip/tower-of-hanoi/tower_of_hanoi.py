def tower_of_hanoi(n, source= 'A', auxiliary='B', destination='C', step=[1]):
    if n == 1:
        print(f"{step[0]}: {source} {destination}")
        step[0] += 1
        return
    tower_of_hanoi(n-1, source, destination, auxiliary, step)
    print(f"{step[0]}: {source} {destination}")
    step[0] += 1
    tower_of_hanoi(n-1, auxiliary, source, destination, step)

number_of_disks = 3
tower_of_hanoi(number_of_disks)